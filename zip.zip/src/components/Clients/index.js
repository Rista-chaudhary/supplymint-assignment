import React from 'react'
import client1 from '../../assets/images/clients/1.png';
import client2 from '../../assets/images/clients/2.png';
import client3 from '../../assets/images/clients/3.png';
import client4 from '../../assets/images/clients/4.png';
import client5 from '../../assets/images/clients/5.png';
import client6 from '../../assets/images/clients/6.png';
import client7 from '../../assets/images/clients/7.png';
import client8 from '../../assets/images/clients/8.png';

export default function Clients() {
  return (
    <div className='container-fluid mt-5'  style={{marginBottom: "120px"}} >
        <div className="ag-text-muted mb-4 ms-5">Our Clients</div>
        <div className="d-flex justify-content-between  align-items-center  mx-5">

            {Array.from(Array(8)).map((_, idx)=><img src={require("../../assets/images/clients/"+(idx+1)+".png")} />)  }

            <p className='ag-text-muted fs-5 mb-0' > & More</p>

        </div>
    </div>
  )
}
