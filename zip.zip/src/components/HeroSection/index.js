import React from "react";
import heroImg from "../../assets/images/hero-img.png";
import signImg from "../../assets/images/signature.png";


export default function HeroSection() {
  return (
    <div className="container ms-5" style={{marginBottom: "120px"}}>
      <div className="d-flex justify-content-between align-items-center1">
        <div className="container1 p1s-5">
          <div className="text-muted mb-2">Procurement Management </div>
          <h1 className=" display-5 fw-700">
            Make Procurement Quick, Transparent, and Hassle-Free
          </h1>
          <img src={signImg} alt="" />
          <p className="mb-5">collaborate and close purchase orders in a jiffy.</p>
          <button className="btn ag-bg-primary text-white px-5 py-3 fw-600 ">Request a Demo</button>
        </div>
        <div className="position-relative1 w-100 h-100">
          <img src={heroImg} alt="" className="position-absolute end-0" />
        </div>
      </div>
    </div>
  );
}
